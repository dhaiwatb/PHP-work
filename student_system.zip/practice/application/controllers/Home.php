<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {
	public function index()
	{
        $this->load->library('pagination');
        $config = [
            'base_url' => base_url().'home/index',
            'total_rows' => $this->crudops->getCount(),
            'per_page' => 5,  
            //'uri_segment' =>3,
            'full_tag_open'     => "<nav aria-label='Page navigation'><ul class='pagination pagination-sm'>",
            'full_tag_close'    => "</ul></nav>",
            'first_tag_open'    => "<li class='page-item'>",
            'first_tag_close'   => "</li>",
            'last_tag_open'     => "<li class='page-item'><a class='page-link'>",
            'last_tag_close'    => "</li>",
            'next_tag_open'     => "<li class='page-item'>",
            'next_tag_close'    => "</li>",
            'pre_tag_open'      => "<li class='page-item'>",
            'pre_tag_close'     => "</li>",
            'num_tag_open'      => "<li class='page-item'><a class='page-link'>",
            'num_tag_close'     => "</li>",
            'cur_tag_open'      => "<li class='active page-item'><a class='page-link'>",
            'cur_tag_close'     => "</a></li>"
        ];
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? ($this->uri->segment(3)) :0;
        $data['users'] = $this->crudops->retFromDb($config['per_page'],$page);
        $this->load->view('userlist',$data);
	}	
    public function deletedata($id)
    {
        $this->crudops->deletedata($id);
        return redirect('home');
    }    
}