<?php include('header.php'); ?>
<div class="row">
    <div class="col-lg-12">
        <h1 id="title">Categories</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-8 mx-auto">
        <table class="table">
            <tr>
                <th class="w-80">Categories</th>
                <th class="w-20">Update/Delete</th>
            </tr>
            <?php //print_r($category);?>
            <?php foreach($category as $value): ?>
                <tr>
                    <td class="w-80">
                        <?=$value['category'];?>
                    </td>
                    <td class="w-20">
                        <button class="btn btn-default">
                            <i class="fa fa-edit"></i>
                            Edit
                        </button>
                        <button class="btn btn-primary">
                            <i class="fa fa-remove"></i>
                            Delete
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
<?php include('footer.php'); ?>