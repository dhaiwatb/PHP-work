<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function index()
    {
        $this->load->view('login');
    }
    public function checkLogin()
    {
        if($this->form_validation->run('login_form') == false)
        {
            $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
            $this->load->view('login');
        }
        else
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $login_id = $this->crudops->checkLogin($username,$password);
            if($login_id)
            {
                $data['user'] = $this->crudops->dispData($login_id);
                $this->session->set_userdata('user_id',$login_id);
                $this->session->set_userdata('user_name',$username);
                return redirect('home');
            }
            else
            {
                $this->form_validation->set_rules('username','Username','callback_checkUserAvail');
                //$this->load->view('login');
                return redirect('login');
            }
        }
    }
    public function checkUserAvail($uname,$pword)
    {
        if($this->crudops->checkUserAvail($uname,$pword))
        {
            return true;
        }
        else
        {
            $this->form_validation->set_message('checkUserAvail', '%s is not available');
            return false;
        }
    }
}
