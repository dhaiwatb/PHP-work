<?php include('header.php'); ?>
<?php 
    $logindata = array(
        'username'=>array(
            'name'          => 'username',
            'id'            => 'username',
            'class'=>'form-control',
            'value' => set_value('username')
        ),
        'password'=>array(
            'name'          => 'password',
            'id'            => 'password',              
            'class'=>'form-control',
            'value' => set_value('password')
        ),
    );

    $formdata = array('class'=>'form','id'=>'login_form','name'=>'login_form');
?>
<div class="row">
    <div class="col-lg-12">
        <h2>Login for Students</h2>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 mx-auto">
        <?=validation_errors();?>
    </div>
</div>
<div class="row">
<div class="col-lg-4 mx-auto">

    <table class="table">
        <?=form_open(base_url().'login/checklogin',$formdata); ?>
            <tr>
                <td>
                    <?php echo form_label('Username','username'); ?>
                </td>
                <td><?php echo form_input($logindata['username']); ?></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><?php echo form_password($logindata['password']); ?></td>
            </tr>
            <tr>
                <td><?php echo form_submit('submit', 'Submit',array('class'=>'btn btn-primary'));?></td>
                <td><?php echo form_reset('reset', 'Clean', array('class' => 'btn btn-danger' ));?></td>
            </tr>
        <?php echo form_close();  

    ?>
    </table>
</div>
</div>
<?php include('footer.php'); ?>