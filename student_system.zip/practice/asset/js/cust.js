$(document).ready(function(){
    //$('#datetimepicker1').datetimepicker();
    //alert('hello world!!');
});