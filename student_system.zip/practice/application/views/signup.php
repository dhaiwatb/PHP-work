
<?php 
    $signupdata = array(
        'username'=>array(
            'name'          => 'username',
            'id'            => 'username',
            'class'    => 'form-control',
            'value' => set_value('username'),
            'placeholder' => 'Enter Username'
        ),
        'password'=>array(
            'name'          => 'password',
            'id'            => 'password' ,                  
            'class'    => 'form-control',
            'value' => set_value('password'),
            'placeholder' => 'Enter Password'
        ),
        'firstname'=>array(
            'name'          => 'firstname',
            'id'            => 'firstname',                    
            'class'    => 'form-control',
            'value' => set_value('firstname'),
            'placeholder' => 'Enter Firstname'
        ),
        'lastname'=>array(
            'name'          => 'lastname',
            'id'            => 'lastname',
            'class'    => 'form-control',
            'value' => set_value('lastname'),
            'placeholder' => 'Enter Lastname'
        )
    );

    $formdata = array('class' => 'form', 'id' => 'signup','name' => 'signup_form');
?>
<?php include('header.php'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2>Signup for Students</h2>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 mx-auto">
        <?=validation_errors();?>            
    </div>
</div>
<div class="row">
    <div class="col-lg-4 mx-auto">
        <table class="table">
            <?=form_open_multipart(base_url().'signup/checksignup',$formdata); ?>
                <tr>
                    <td><?=form_input($signupdata['username']); ?></td>
                    
                </tr>
                <tr>
                    <td><?=form_password($signupdata['password']); ?></td>
                    
                </tr>
                <tr>
                    <td><?=form_input($signupdata['firstname']); ?></td>
                    
                </tr>
                <tr>
                    <td><?=form_input($signupdata['lastname']); ?></td>
                    
                </tr>
                <tr>
                    <td>    
                        <div class="input-group">
                          <div class="custom-file">
                              <!--input type="file" class="custom-file-input" id="customFileLang"-->
                              <?=form_upload(['name'=>'userimage','class'=>'custom-file-input form-control','id'=>'customFileLang'])?>
                              <?=form_label('Choose file','customFileLang',['class'=>'custom-file-label form-control'])?>
                            </div>
                        </div>
                        <div id="imageerror">
                            <?php echo $imageerror = isset($upload_error)?$upload_error:""; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td  colspan="2">
                        <?=form_submit('submit', 'Submit',array('class'=>'btn btn-primary')); ?>
                        <?=form_reset('reset', 'Clean',array('class'=>'btn btn-danger'));?>
                    </td>
                </tr>
            <?php echo form_close();  ?>
        </table>
    </div>
</div>
<?php include('footer.php'); ?>