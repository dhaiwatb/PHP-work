<?php
class Admin extends BackendController
{
    public function index()
    {
        $this->load->library('pagination');
        $config = [
            'base_url' => base_url().'admin/index',
            'total_rows' => $this->products->getCount(),
            'per_page' => 10,  
            //'uri_segment' =>3,
            'full_tag_open'     => "<nav aria-label='Page navigation'><ul class='pagination justify-content-center'>",
            'full_tag_close'    => "</ul></nav>",
            'first_tag_open'    => "<li class='page-item page-link'>",
            'first_tag_close'   => "</li>",
            'last_tag_open'     => "<li class='page-item page-link'>",
            'last_tag_close'    => "</li>",
            'next_tag_open'     => "<li class='page-item page-link'>",
            'next_tag_close'    => "</li>",
            'prev_tag_open'      => "<li class='page-item page-link'>",
            'prev_tag_close'     => "</li>",
            'num_tag_open'      => "<li class='page-item page-link'>",
            'num_tag_close'     => "</li>",
            'cur_tag_open'      => "<li class='page-item active page-link'><b style='text-decoration: underline overline red;'>",
            'cur_tag_close'     => "</b></li>"
        ];
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? ($this->uri->segment(3)) :0;
        $data['products'] = $this->products->product_list($config['per_page'],$page);        
        $this->load->view('admin/product_list',$data);
    }
    public function insert_products()
    {
        $config = [
            'upload_path' => './uploads/',
            'allowed_types' => 'jpg|png|jpeg'
            //'file_name' => isset($this->session->userdata('user_name'))?$this->session->userdata('user_name'):'image'
        ];
        $this->load->library('upload',$config);
        $this->upload->initialize($config);

        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
        
        $this->form_validation->set_rules('product_name','Product Name','required');
        $this->form_validation->set_rules('product_qty','Product Quantity','required|numeric');
        $this->form_validation->set_rules('product_price','Product Price','required|numeric');
        $this->form_validation->set_rules('product_image','Product image','required');

        if($this->form_validation->run('product_form') == false  && $this->upload->do_upload('product_image') == false)
        {
            $data['upload_error'] = $this->upload->display_errors('<p class="text-danger">','</p>');
            $this->load->view('admin/product_form',$data);
        }
        else
        {
            $sku            =   rand(200,300);
            $product_name   =   $this->input->post('product_name'); 
            $quantity       =   $this->input->post('product_qty');
            $price          =   $this->input->post('product_price');
            $data = $this->upload->data();
            //print_r($data);
            $image_path = base_url('uploads/'.$data['raw_name'].$data['file_ext']);
            $this->products->insert_products($sku,$product_name,$quantity,$price,$image_path);
            return redirect('admin/product_list');
        }
    }   
    public function product_form()
    {
        $this->load->view('admin/product_form');
    } 
    public function product_list()
    {
        $data['products'] = $this->products->product_list();
        $this->load->view('admin/product_list',$data);
    }
    public function category_list($mainCategory = "")
    {
        $mainCategory = $this->input->post('maincategory');
        $data['category'] = $this->products->getCategory($mainCategory);
        return $data;
    }
    public function maincategory_list()
    {
        $data['mainCategory'] = $this->products->getMainCategory();
        return $data;
    }
    public function get_filtereddata()
    {
        $data['mainCategory'] = $this->products->getMainCategory();
        $data['mainCategory_count'] = count($data['mainCategory']);
        $this->load->view('admin/filtered_data',$data);
    }
    public function get_products($mc = '',$c ='')
    {
        $mc = $this->input->post('maincategory');
        $c = $this->input->post('category');
        $data['items'] = $this->products->getProducts($mc,$c);
        return $data;
    }
}