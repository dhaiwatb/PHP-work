<?php include 'header.php' ?>
<div class="row">
    <div class="col-lg-12">
        <h1>Additional details for students</h1>
        <hr>
    </div>
</div>
<?php     
$user = $users[0]; 
?>
<div class="row">
    <div class="col-lg-5 mx-auto">
        <?=form_open(base_url().'updateuserdata/validate_details',['name'=>'student_details','class'=>'form'])?>
        <div class="form-group">
            <div class="input-group">
                <?= form_hidden('user_id',$user['id'])?>
            </div>
            <?php echo form_error('user_id','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?=form_label('Username','username',['class'=>'text-primary'])?>
            <div class="input-group">
                <?=form_input(['name'=>'username','class'=>'form-control','value'=>ucfirst($user['fname'])." ".ucfirst($user['lname']),'disabled'=>'true'])?>
            </div>
        </div>
        <div class="form-group">
            <?=form_label('Gender','gender',['class'=>'text-primary'])?>
            <div class="input-group">
                <?=form_label('Male','male')?>
                <?=form_radio(['name'=>'gender','value'=>'male','checked'=>set_radio('gender', 'M'),'class'=>'m-1']) ?>
                <?=form_label('Female','female')?>
                <?=form_radio(['name'=>'gender','value'=>'female','checked'=>set_radio('gender', 'F'),'class'=>'m-1']) ?>
            </div>
            <?php echo form_error('gender','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?=form_label('Hobbies','hobbies',['class'=>'text-primary'])?>
            <div class="input-group">
                <?=form_label('Acrobatics','acrobatics')?>
                <?=form_checkbox(['name'=>'hobbies[]','value'=>'acrobatics','class'=>'m-1']) ?>
                <?=form_label('Beatboxing','beatboxing')?>
                <?=form_checkbox(['name'=>'hobbies[]','value'=>'beatboxing','class'=>'m-1']) ?>
                <?=form_label('Karate','karate')?>
                <?=form_checkbox(['name'=>'hobbies[]','value'=>'karate','class'=>'m-1']) ?>
                <?=form_label('Collecting','collecting')?>
                <?=form_checkbox(['name'=>'hobbies[]','value'=>'collecting','class'=>'m-1']) ?>
            </div>
            <?php echo form_error('hobbies[]','<p class="text-danger">','</p>');?>
        </div>
        <div class="form-group">
            <?=form_label('Birthdate','birthdate',['class'=>'text-primary'])?>
            <div class='input-group date'>
                <?=form_input(['name'=>'birthdate','class'=>'form-control','id'=>'datepicker','autocomplete'=>'off'])?>
                    <!--span class="input-group-addon">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span-->
                </div>
                <?php echo form_error('birthdate','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?=form_label('Country','country',['class'=>'text-primary'])?>
                <select name="country" id="country" class="form-control">
                    <option value="0">Select country</option>
                    <?php foreach ($countries as $country): ?>
                        <?php for($i=0;$i<count($country);$i++): ?>
                            <option value="<?=$country[$i]['id']?>"><?=$country[$i]['country_name']?></option>
                        <?php endfor;                ?>
                    <?php         endforeach; ?>
                </select>
            </div>            
            <?php echo form_error('country','<p class="text-danger">','</p>');?>
            <div class="form-group" id="state-drop-down">
                <?=form_label('State','state',['class'=>'text-primary'])?>
                <select name="state" id="state" class="form-control">
                    <option value="0">Select State</option>
                </select>
                <?php echo form_error('state','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group" id="city-drop-down">
                <?=form_label('City','city',['class'=>'text-primary'])?>
                <select name="city" id="city" class="form-control">
                    <option value="0">Select City</option>
                </select>
                <?php echo form_error('city','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?=form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Submit'])?>
                <?=form_reset(['name'=>'reset','class'=>'btn btn-danger','value'=>'Clear'])?>
            </div>
            <?=form_close()?>
        </div>
    </div>

    <?php include 'footer.php' ?>
