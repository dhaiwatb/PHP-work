<?php

class Crudops extends CI_Model{
	public function retFromDb($limit,$start)
	{
		$q = $this->db
		->limit($limit,$start)
		->get('student_info');
		if($q->num_rows())	
		{
			return $q->result_array();
		}
		else
		{
			return false;
		}
	}
	public function dispData($id)
	{
		$q = $this->db->where('id',$id)
						->get('student_info');
		if($q->num_rows())	
		{
			return $q->result_array();
		}
		else
		{
			return false;
		}
	}
	public function getCount()
	{
		$q = $this->db->count_all('student_info');

		return $q;
	}
	public function checkLogin($uname,$pword)
	{
		$q = $this->db->where(['uname'=>$uname,'pword'=>$pword])
				->get('student_info');

		if($q->num_rows())
		{
			return $q->row()->id;
		}
		else
		{
			return false;
		}
	}
	public function insertdata($uname,$pword,$fname,$lname,$ipath)
	{
		$insertdata = array(
			'uname' => $uname,
			'pword' => $pword,
			'fname' => $fname,
			'lname' => $lname,
			'image_path' => $ipath
		);
		$q = $this->db
			->set($insertdata)
			->insert('student_info');
	}
	public function updatedata($uname,$pword,$fname,$lname,$id)
	{
		$updatedata = array(
			'uname' => $uname,
			'pword' => $pword,
			'fname' => $fname,
			'lname' => $lname
		);
		$q = $this->db
		->set($updatedata)
		->where('id',$id)
		->update('student_info');
		//print_r($q);exit;
	}
	public function deletedata($id)
	{
		$q = $this->db
		->where('id',$id)
		->delete('student_info');
	}
	public function numrecords()
	{
		$q = $this->db->get('student_info');

		return $q->num_rows();
	}
	public function checkUserAvail($uname,$pword)
	{
		$q = $this->db->select('uname')
		->where(['uname'=>$uname,'pword'=>$pword])
		->get('student_info');

		if($q->num_rows())
		{
			return $q->row();
		}
		else
		{
			return false;
		}
	}
}