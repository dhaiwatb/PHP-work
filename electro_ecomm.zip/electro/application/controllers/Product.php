<?php

class Product extends FrontendController    {
    public function index()
    {
        $data['title'] = "Ecommerce - eMall";

        $this->load->view('templates/header',$data);
        $this->load->view('templates/navigation');
        $this->load->view('homepage',$data);
        $this->load->view('templates/footer');
    }
    public function product_page($title = "",$url ="",$product_data="")
    {
        $data['title'] = $title;
        $data['url'] = $url;
        $data['product_data'] =  $product_data;

        $this->load->view('templates/header',$data);
        $this->load->view('templates/navigation');
        $this->load->view('product_page',$data);
        $this->load->view('templates/footer');    
    }
    
}