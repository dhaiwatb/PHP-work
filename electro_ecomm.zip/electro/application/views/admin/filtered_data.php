<?php include("header.php");?>
<div class="row">
    <div class="col-lg-12">
        <h1 id="title">Get Filtered data</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 mx-auto">            
        <form action="#" id="category_filter">                

            <?php //print_r($mainCategory); ?>
            <span class="float">
                <?php echo form_label("Main Category",'maincategory',['class'=>'form-label']) ?>
                <select name="maincategory" id="maincategory" class="form-control mb-3">
                    <option value="Select main category">Select Main Category</option>
                    <?php for($i=0;$i<$mainCategory_count;$i++): ?>
                        <option value="<?=$mainCategory[$i]['mainCategory'];?>"><?=$mainCategory[$i]['mainCategory'];?></option>
                    <?php endfor; ?>
                </select>
                <?php echo form_label("Category",'category',['class'=>'form-label']) ?>
                <select name="category" id="category-dropdown" class="form-control mb-3">
                    <option value="Select category">Select Category</option>
                </select>
            </span>
        </form>            
    </div>
</div>
<div class="row">
    <div class="col-lg-10 mx-auto">
        <div id="product-list">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th class="w-25">Product ID</th>
                        <th class="w-60">Product Name</th>
                        <th class="w-15">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td  colspan="3">Data not found</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include("footer.php");?>