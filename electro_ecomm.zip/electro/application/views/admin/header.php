<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
     <?php 
      //echo link_tag('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');     
      echo link_tag('https://bootswatch.com/4/journal/bootstrap.css');     
      echo link_tag('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'); 
      echo link_tag('https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css');
      echo link_tag('https://demos.creative-tim.com/datepicker/assets/css/bootstrap-datepicker.css');
      echo link_tag('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');
    ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?=base_url('welcome');?>">Electro</a>  
  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a href="<?=base_url('admin/index')?>" class="nav-link">Products' List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('admin/product_form');?>">Insert product</a>
      </li>
      <li class="nav-item">
        <a href="<?=base_url('admin/get_filtereddata')?>" class="nav-link">Get filtered Data</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="text" placeholder="Search">
      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search <i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
  </div>
</nav>
<div class="container">